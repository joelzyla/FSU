
//    By: Joel Zyla
//    IOS Phonegap Application
//    AVF 1306

$("#demopage").on('pageinit', function () {
	//code needed for home page goes here
	console.log("Demo page loaded!");
});



$("#instagrampage").on('pageinit', function () {
	//code needed for instagram page goes here
	console.log("Instagram page loaded!");

	$(function() {
	    $.ajax({
	    	type: "GET",
	        dataType: "jsonp",
	        cache: false,
	        url: "https://api.instagram.com/v1/media/popular?callback=?&amp;client_id=6a46e3b2ad4d45469ce7a38f5387986a",
	        success: function(data) {
	            for (var i = 0; i < 5; i++) {
	            	$(".instaDiv").append("<div class='instaContainer'><a target='_blank' href='" + data.data[i].link +"'><img class='instaImage' src='" + data.data[i].images.standard_resolution.url +"' /></a></div>");   
	      		};  
	  			console.log(data);                       
	        }
	    });
	});

});


$("#weatherpage").on('pageinit', function () {

	$(function() {
	    $.ajax({
	    	type: "GET",
	        dataType: "jsonp",
	        cache: false,
	        url: "https://api.forecast.io/forecast/5c0045fc0ae053e170f4174e9ec88ae4/37.8267,-122.423?callback=?",
	        success: function(info) {
	        	console.log(info);
	        	console.log(info.daily.icon);
	        	for (var i = 0; i < 1; i++) {
	        		$(".weatherDiv").append("<img class='weatherImage' src='img/" + info.daily.icon + ".png' />"); 
	        		//$(".weatherDiv").append("<p id='currentWeatherItem'>" + info.daily.data.0.summary + "</br>" + info.daily.0 + "</br>" + info.hourly.summary + "</p>");
	        		$(".weatherDiv").append("<ul>");
	        		$(".weatherDiv").append("<li id='currentWeatherItem'>Cloudcover: " + info.timezone + "</li>");
	        		$(".weatherDiv").append("<li id='currentWeatherItem'>Cloudcover: " + info.currently.cloudCover + "</li>");
	        		$(".weatherDiv").append("<li id='currentWeatherItem'>Dew Point: " + info.currently.dewPoint + "</li>");
	        		$(".weatherDiv").append("<li id='currentWeatherItem'>Humidity: " + info.currently.humidity + "</li>");
	        		$(".weatherDiv").append("<li id='currentWeatherItem'>Ozone: " + info.currently.ozone + "</li>");
	        		$(".weatherDiv").append("<li id='currentWeatherItem'>Precipitation Intensity: " + info.currently.precipIntensity + "</li>");
	        		$(".weatherDiv").append("<li id='currentWeatherItem'>Pressure: " + info.currently.pressure + "</li>");
	        		$(".weatherDiv").append("<li id='currentWeatherItem'>Temperature: " + info.currently.temperature + "</li>");
	        		$(".weatherDiv").append("<li id='currentWeatherItem'>Time: " + info.currently.time + "</li>");
	        		$(".weatherDiv").append("<li id='currentWeatherItem'>Visibility: " + info.currently.visibility + "</li>");
	        		$(".weatherDiv").append("<li id='currentWeatherItem'>Wind Bearing: " + info.currently.windBearing + "</li>");
	        		$(".weatherDiv").append("<li id='currentWeatherItem'>Wind Speed: " + info.currently.windSpeed + "</li>");

	        	//	<img src='file:///Users/joelzyla/Desktop/FSU/AVF/week2/ios/vfw/www/img/clear-day.png' />
	        	};
	  			                       
	        }
	    });
	});




	//code needed for weather page goes here
	console.log("Weather page loaded!");
});



